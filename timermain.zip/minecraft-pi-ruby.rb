class Minecraft
  def say( s )
    puts s
  end
  
  def set_block( x, y, z, b )
  end
end
