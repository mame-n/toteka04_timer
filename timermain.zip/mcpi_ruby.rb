#require 'minecraft-pi-ruby'
require './minecraft-pi-ruby'

class NumericalMCPI
  def initialize
    @mc = Minecraft.new
    @mc.reset
  end

  def NummericalMCPI::say( s )
    @mc.say "MCPI::Ruby : #{s}"
  end

  def disp_min( number )
#    puts "#{number} min"
    [8, 0].each do |offset|
      ddigt( number % 10, offset )
      number /= 10
    end
  end

  def disp_sec( number )
#    puts "#{number} sec"
    [28, 20].each do |offset|
      ddigt( number % 10, offset )
      number /= 10
    end
  end

  def ddigt( number, digit )
    Thread.new() do
      14.downto(4) do |y|
        0.upto(5) do |x|
          block = TNum::T[number][14-y][x]
          @mc.set_block( x+digit, y, 0, block ) if block
        end
      end
    end
  end
end

class Minecraft
  def reset
    mc.set_blocks(-100, 0,  -100, 100, 63, 100, Block::AIR)
    mc.set_blocks(-100, -1,  -100, 100, 1, 100, Block::GRASS)
    mc.set_blocks(-100, -63,  -100, 100, -2, 100, Block::STONE)

    mc.set_player_position(23, 2, 19)
  end
end
