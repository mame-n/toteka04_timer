require 'rinda/tuplespace'
require './mcpi_ruby'
require './num_block'
require './timer'

class Timer_ctrl
  def initialize
    create_tapleSpace
    DRb.start_service
    @ts = DRbObject.new_with_uri('druby://localhost:9999')
  end

  def create_tapleSpace
    ts = Rinda::TupleSpace.new
    Thread.new() do
      DRb.start_service('druby://localhost:9999', ts)
      puts DRb.uri
      DRb.thread.join
    end
  end

  def set_time( min )
    NumericalMCPI.say "Set time as #{min} min."

    total_sec = (min * 60).to_i
    @prev_sec = total_sec % 60
    disp_time( total_sec )

    @timer = Timer.new(1.0) do
      puts "Write #{total_sec}"
      @ts.write(["timer", total_sec])
      total_sec -= 1
    end
  end

  def start_timer
    @timer.start()
    while (sec = @ts.take(["timer", nil])[1]) != 0
      puts "Inside #{sec}"
      disp_time( sec )
    end
    @timer.stop()
    puts "Outside"

#    wait_threads_stop()
    disp_time( 0 )
  end

  def disp_time( total_sec )
    min = total_sec / 60
    sec = total_sec % 60
    
    mcpi = NumericalMCPI.new
    mcpi.disp_sec( sec )
    mcpi.disp_min( min ) if @prev_sec <= sec
    @prev_sec = sec
  end

end

tm = Timer_ctrl.new
tm.set_time( 1.1 )
tm.start_timer
