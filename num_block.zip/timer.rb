class Timer

  public
  def initialize(interval, &callback_block)
    @loop_enable = false
    @interval = interval
    @callback_block = callback_block
  end

  def start()
    @loop_enable = true
    loop_start()
  end

  def stop()
    @loop_enable = false
  end

  def wait_threads_stop(number_of_thread = 1, timeout = 200)
    puts("\n\nWaiting for finishing all threds.")
    c = 0
    while Thread.list.length > number_of_thread
      puts(Thread.list.length)
      c += 1
      if c > timeout then
        puts('time out')
        break
      end
      sleep(0.1)
    end
  end

  private
  def loop_start()
    Thread.new(){
      while @loop_enable
        @callback_block.call()
        sleep(@interval)
      end
      puts "loop_enable #{@loop_enable}"
    }
  end
end
